# PiTrezor Display Integration - Source Code Package

This package contains all the source code and scripts developed for integrating ILI9341 SPI displays with PiTrezor firmware.

## 📁 Contents

### Core Scripts
- **`build-fbcp-ili9341.sh`** - Automated build script for fbcp-ili9341 driver with PiTrezor optimizations
- **`start_mirrorhdmi.sh`** - Display mirror service that starts the framebuffer copy driver  
- **`start_pitrezor.sh`** - Modified PiTrezor startup script for universal firmware

### Diagnostic Tools
- **`comprehensive-display-debug.sh`** - Complete diagnostic script for troubleshooting display issues
- **`hardware-test.sh`** - Basic hardware test for GPIO pins and backlight control

## 🛠️ Technical Details

### Build Script Features
- **Automatic dependency installation** (git, cmake, build-essential)
- **Pi Zero optimization** (ARMv6Z, single core)
- **Configuration-driven builds** (reads from pitrezor.config)
- **Multiple display support** (ILI9341, ILI9486, Adafruit PiTFT, WaveShare)
- **Intelligent fallbacks** (uses basic fbcp if advanced build fails)
- **Progress indicators** for long operations

### Display Service Architecture
- **Two-service approach** prevents timing conflicts:
  1. PiTrezor application starts first
  2. Display mirror service starts after 3-second delay
- **Automatic driver selection** (optimized vs basic)
- **Configuration validation** and error reporting

### Reverse Transplant Method
Instead of fixing display drivers on new firmware, we:
1. Used old working image as base (proven display drivers)
2. Transplanted modern firmware binaries
3. Updated startup scripts for unified firmware
4. Configured for universal (not bitcoin-only) mode

## 🎯 Key Innovations

1. **Configuration-driven builds** - No hardcoded values, everything reads from config
2. **Intelligent timing** - Display service waits for PiTrezor to initialize  
3. **Graceful fallbacks** - Multiple backup options if primary driver fails
4. **Comprehensive diagnostics** - Complete troubleshooting toolkit included
5. **Firmware agnostic** - Works with old and new PiTrezor versions

## 📋 Usage

### Auto-Build (Recommended)
1. Copy `build-fbcp-ili9341.sh` to Pi
2. Make executable: `chmod +x build-fbcp-ili9341.sh`
3. Run: `sudo ./build-fbcp-ili9341.sh`

### Manual Installation
1. Copy scripts to `/usr/bin/`
2. Make executable: `chmod +x /usr/bin/start_*`
3. Add inittab entries (see source-files package)
4. Configure pitrezor.config (see source-files package)

### Diagnostics
1. Copy diagnostic scripts to Pi
2. Run: `sudo ./comprehensive-display-debug.sh`
3. Review output for issues

## 🔧 Customization

### GPIO Pin Configuration
Edit in `pitrezor.config`:
```bash
export FBCP_GPIO_DC=24          # Data/Control
export FBCP_GPIO_RESET=25       # Reset  
export FBCP_GPIO_BACKLIGHT=18   # Backlight
```

### Display Type Selection
```bash
export FBCP_DISPLAY_TYPE=ILI9341  # or ILI9486, ADAFRUIT_PITFT, WAVESHARE35B
```

### Performance Tuning
```bash
export FBCP_SPI_SPEED_DIVISOR=40  # Higher = slower/stable, Lower = faster
```

### Advanced Options
```bash
export FBCP_EXTRA_CMAKE_ARGS="-DBACKLIGHT_CONTROL=ON -DDISPLAY_FORCE_VSYNC_OFF=ON"
```

## 🐛 Troubleshooting

### Common Issues
1. **Black screen** - Usually SPI not enabled in `/boot/config.txt`
2. **No framebuffer devices** - Check `dtparam=spi=on` in boot config  
3. **Build failures** - Verify internet connection for git clone
4. **Timing issues** - Adjust delay in `start_mirrorhdmi.sh`

### Diagnostic Steps
1. Run `comprehensive-display-debug.sh`
2. Check SPI interface: `ls /dev/spi*`
3. Verify GPIO control: `hardware-test.sh` 
4. Test framebuffer: `cat /dev/urandom > /dev/fb1`

## 📚 References

- [fbcp-ili9341 GitHub](https://github.com/juj/fbcp-ili9341)
- [PiTrezor Documentation](https://github.com/satoshilabs/pitrezor)
- [Raspberry Pi SPI Documentation](https://www.raspberrypi.org/documentation/hardware/raspberrypi/spi/)

## 📜 License

These scripts are provided as-is for educational and development purposes. Original fbcp-ili9341 code is subject to its own license terms.

---

**Created: November 12, 2025**  
**Project: PiTrezor ILI9341 Display Integration**