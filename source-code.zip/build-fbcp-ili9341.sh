#!/bin/bash
#
# PiTrezor Display Driver Auto-Build Script
# Created: November 12, 2025
# Purpose: Automatically build and configure fbcp-ili9341 for PiTrezor
#

set -e  # Exit on error

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BUILD_DIR="/tmp/fbcp-ili9341-build"
INSTALL_DIR="/usr/bin"

echo "========================================="
echo "  PiTrezor Display Driver Builder"
echo "========================================="

show_progress() {
    echo "Status: $1"
    for i in {1..5}; do
        echo -n "."
        sleep 0.5
    done
    echo ""
}

# Check if running on Pi Zero
if ! grep -q "BCM2708\|BCM2835" /proc/cpuinfo; then
    echo "Warning: Not running on Pi Zero, this may not work correctly"
fi

# Install build dependencies
echo "Installing build dependencies..."
show_progress "Installing build tools"
apt-get update -q
apt-get install -y git cmake build-essential

# Clean up any previous builds
rm -rf "$BUILD_DIR"
mkdir -p "$BUILD_DIR"
cd "$BUILD_DIR"

# Clone fbcp-ili9341 source
show_progress "Downloading display driver source code"
git clone https://github.com/juj/fbcp-ili9341.git .

# Configure build for PiTrezor
echo "Configuring build for PiTrezor hardware..."

# Load configuration
source /var/volatile/pitrezor.config 2>/dev/null || source /boot/pitrezor.config 2>/dev/null || true

# Set default display type if not configured
FBCP_DISPLAY_TYPE=${FBCP_DISPLAY_TYPE:-ILI9341}
FBCP_GPIO_DC=${FBCP_GPIO_DC:-24}
FBCP_GPIO_RESET=${FBCP_GPIO_RESET:-25}
FBCP_GPIO_BACKLIGHT=${FBCP_GPIO_BACKLIGHT:-18}
FBCP_SPI_SPEED_DIVISOR=${FBCP_SPI_SPEED_DIVISOR:-40}

# Configure cmake arguments based on display type
CMAKE_ARGS="-DSINGLE_CORE_BOARD=ON"
CMAKE_ARGS="$CMAKE_ARGS -DARMV6Z=ON"
CMAKE_ARGS="$CMAKE_ARGS -DGPIO_TFT_DATA_CONTROL=$FBCP_GPIO_DC"
CMAKE_ARGS="$CMAKE_ARGS -DGPIO_TFT_RESET_PIN=$FBCP_GPIO_RESET"
CMAKE_ARGS="$CMAKE_ARGS -DGPIO_TFT_BACKLIGHT=$FBCP_GPIO_BACKLIGHT"
CMAKE_ARGS="$CMAKE_ARGS -DSPI_BUS_CLOCK_DIVISOR=$FBCP_SPI_SPEED_DIVISOR"
CMAKE_ARGS="$CMAKE_ARGS -DBACKLIGHT_CONTROL=ON"
CMAKE_ARGS="$CMAKE_ARGS -DDISPLAY_FORCE_VSYNC_OFF=ON"

# Add display-specific arguments
case "$FBCP_DISPLAY_TYPE" in
    ILI9341)
        CMAKE_ARGS="$CMAKE_ARGS -DILI9341=ON"
        ;;
    ILI9486)
        CMAKE_ARGS="$CMAKE_ARGS -DILI9486=ON"
        ;;
    ADAFRUIT_PITFT)
        CMAKE_ARGS="$CMAKE_ARGS -DADAFRUIT_ILI9341_PITFT=ON"
        ;;
    WAVESHARE35B)
        CMAKE_ARGS="$CMAKE_ARGS -DWAVESHARE35B_ILI9486=ON"
        ;;
    *)
        echo "Unknown display type: $FBCP_DISPLAY_TYPE, defaulting to ILI9341"
        CMAKE_ARGS="$CMAKE_ARGS -DILI9341=ON"
        ;;
esac

# Add any extra cmake arguments
if [ -n "$FBCP_EXTRA_CMAKE_ARGS" ]; then
    CMAKE_ARGS="$CMAKE_ARGS $FBCP_EXTRA_CMAKE_ARGS"
fi

echo "CMAKE Arguments: $CMAKE_ARGS"

# Build the driver
show_progress "Configuring build system"
mkdir -p build
cd build
cmake .. $CMAKE_ARGS

show_progress "Compiling optimized driver"
make -j$(nproc)

if [ -f "./fbcp-ili9341" ]; then
    echo "✓ Build successful!"
    
    # Install the driver
    show_progress "Installing driver"
    cp ./fbcp-ili9341 "$INSTALL_DIR/"
    chmod +x "$INSTALL_DIR/fbcp-ili9341"
    
    # Create success marker
    touch /var/lock/fbcp-ili9341-built
    
    echo "✓ Driver installed successfully!"
    echo "✓ Configuration: $FBCP_DISPLAY_TYPE display"
    echo "✓ GPIO DC: $FBCP_GPIO_DC"
    echo "✓ GPIO Reset: $FBCP_GPIO_RESET" 
    echo "✓ GPIO Backlight: $FBCP_GPIO_BACKLIGHT"
else
    echo "✗ Build failed!"
    echo "Falling back to basic driver..."
    
    # Try to use basic fbcp if available
    if command -v fbcp >/dev/null; then
        echo "Using basic fbcp driver as fallback"
    else
        echo "No fallback driver available"
        exit 1
    fi
fi

# Cleanup
cd /
rm -rf "$BUILD_DIR"

echo "Display driver setup complete!"