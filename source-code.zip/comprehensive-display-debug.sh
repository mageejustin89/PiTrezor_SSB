#!/bin/bash

echo "========================================="
echo "  PiTrezor Display Diagnostic Tool"
echo "  Created: $(date)"
echo "========================================="

# Create log file
LOG_FILE="/tmp/display_debug.log"
exec > >(tee -a "$LOG_FILE")
exec 2>&1

echo ""
echo "1. System Information:"
echo "   Hostname: $(hostname)"
echo "   Date: $(date)"
echo "   Uptime: $(uptime)"
echo "   Kernel: $(uname -a)"

echo ""
echo "2. Configuration Check:"
if [ -f /boot/pitrezor.config ]; then
    echo "   ✓ Found /boot/pitrezor.config"
    source /boot/pitrezor.config
else
    echo "   ✗ No /boot/pitrezor.config found"
    if [ -f /var/volatile/pitrezor.config ]; then
        echo "   ✓ Found /var/volatile/pitrezor.config"
        source /var/volatile/pitrezor.config
    elif [ -f /usr/share/pitrezor/pitrezor.config ]; then
        echo "   ✓ Found /usr/share/pitrezor/pitrezor.config"
        source /usr/share/pitrezor/pitrezor.config
    else
        echo "   ✗ No pitrezor.config found anywhere!"
    fi
fi

echo "   TREZOR_OLED_TYPE: ${TREZOR_OLED_TYPE:-not set}"
echo "   ENABLE_FBCPILI9341_DISPLAY: ${ENABLE_FBCPILI9341_DISPLAY:-not set}"
echo "   TREZOR_OLED_SCALE: ${TREZOR_OLED_SCALE:-not set}"

echo ""
echo "3. Process Check:"
if pgrep -f pitrezor > /dev/null; then
    echo "   ✓ PiTrezor process running:"
    ps aux | grep -i trezor | grep -v grep | head -3
else
    echo "   ✗ No PiTrezor process found"
fi

if pgrep -f fbcp > /dev/null; then
    echo "   ✓ FBCP process running:"
    ps aux | grep fbcp | grep -v grep
else
    echo "   ✗ No FBCP process found"
fi

echo ""
echo "4. Binary Check:"
if [ -f /usr/bin/fbcp-ili9341 ]; then
    echo "   ✓ fbcp-ili9341 binary exists"
    ls -la /usr/bin/fbcp-ili9341
else
    echo "   ✗ fbcp-ili9341 binary missing"
fi

if [ -f /usr/bin/start_mirrorhdmi ]; then
    echo "   ✓ start_mirrorhdmi script exists"
    ls -la /usr/bin/start_mirrorhdmi
    echo "   Script content:"
    cat /usr/bin/start_mirrorhdmi | sed 's/^/      /'
else
    echo "   ✗ start_mirrorhdmi script missing"
fi

echo ""
echo "5. SPI Interface Check:"
if lsmod | grep -q spi; then
    echo "   ✓ SPI modules loaded:"
    lsmod | grep spi | sed 's/^/      /'
else
    echo "   ✗ No SPI modules loaded"
fi

if ls /dev/spi* 2>/dev/null; then
    echo "   ✓ SPI devices found:"
    ls -la /dev/spi* | sed 's/^/      /'
else
    echo "   ✗ No SPI devices found"
fi

echo ""
echo "6. GPIO Status:"
for pin in 18 24 25; do
    if [ -d /sys/class/gpio/gpio$pin ]; then
        direction=$(cat /sys/class/gpio/gpio$pin/direction 2>/dev/null || echo "error")
        value=$(cat /sys/class/gpio/gpio$pin/value 2>/dev/null || echo "error")
        echo "   GPIO $pin: direction=$direction, value=$value"
    else
        echo "   GPIO $pin: not exported"
    fi
done

echo ""
echo "7. Framebuffer Check:"
if ls /dev/fb* 2>/dev/null; then
    echo "   ✓ Framebuffer devices:"
    ls -la /dev/fb* | sed 's/^/      /'
    
    for fb in /dev/fb*; do
        if [ -c "$fb" ]; then
            echo "   Info for $fb:"
            if command -v fbset >/dev/null; then
                fbset -fb "$fb" 2>/dev/null | sed 's/^/      /' || echo "      Cannot read fbset info"
            else
                echo "      fbset command not available"
            fi
        fi
    done
else
    echo "   ✗ No framebuffer devices found"
fi

echo ""
echo "8. Display Test:"
echo "   Attempting to write test pattern to display..."

# Try to export GPIO pins if not already done
for pin in 18 24 25; do
    echo $pin > /sys/class/gpio/export 2>/dev/null || true
    echo out > /sys/class/gpio/gpio$pin/direction 2>/dev/null || true
done

# Set backlight on
echo 1 > /sys/class/gpio/gpio18/value 2>/dev/null && echo "   ✓ Backlight GPIO set HIGH" || echo "   ✗ Cannot set backlight GPIO"

# Reset display
echo 0 > /sys/class/gpio/gpio25/value 2>/dev/null
sleep 0.1
echo 1 > /sys/class/gpio/gpio25/value 2>/dev/null && echo "   ✓ Reset sequence completed" || echo "   ✗ Cannot control reset GPIO"

# Try writing to framebuffer
if [ -c /dev/fb1 ]; then
    echo "   Attempting to write red pattern to /dev/fb1..."
    dd if=/dev/zero bs=1024 count=300 2>/dev/null | tr '\0' '\xff' > /dev/fb1 2>/dev/null && echo "   ✓ Wrote test pattern" || echo "   ✗ Cannot write to framebuffer"
elif [ -c /dev/fb0 ]; then
    echo "   Attempting to write red pattern to /dev/fb0..."
    dd if=/dev/zero bs=1024 count=300 2>/dev/null | tr '\0' '\xff' > /dev/fb0 2>/dev/null && echo "   ✓ Wrote test pattern" || echo "   ✗ Cannot write to framebuffer"
else
    echo "   ✗ No framebuffer devices available"
fi

echo ""
echo "9. Service Status:"
echo "   Checking init processes..."
ps aux | grep -E "(start_pitrezor|start_mirrorhdmi|fbcp)" | grep -v grep | sed 's/^/      /'

echo ""
echo "10. Attempting Manual FBCP Start:"
if [ -f /usr/bin/fbcp-ili9341 ]; then
    echo "   Killing any existing fbcp processes..."
    killall fbcp-ili9341 2>/dev/null || true
    sleep 1
    
    echo "   Starting fbcp-ili9341 manually..."
    timeout 5 /usr/bin/fbcp-ili9341 &
    FBCP_PID=$!
    sleep 2
    
    if kill -0 $FBCP_PID 2>/dev/null; then
        echo "   ✓ fbcp-ili9341 started successfully (PID: $FBCP_PID)"
    else
        echo "   ✗ fbcp-ili9341 failed to start or crashed"
    fi
else
    echo "   ✗ fbcp-ili9341 binary not found"
fi

echo ""
echo "========================================="
echo "Diagnostic complete!"
echo "Log saved to: $LOG_FILE"
echo ""
echo "If you see this on your display, the basic"
echo "framebuffer is working!"
echo ""
echo "Copy this log file to analyze the issue:"
echo "scp pi@your-pi-ip:$LOG_FILE ."
echo "========================================="

# Keep log around
cp "$LOG_FILE" /home/root/display_debug_$(date +%Y%m%d_%H%M%S).log 2>/dev/null || true