#!/bin/bash

echo "Quick Hardware Test for ILI9341 Display"
echo "========================================"

# Enable GPIO pins
echo "Setting up GPIO pins..."
echo 18 > /sys/class/gpio/export 2>/dev/null  # Backlight
echo 24 > /sys/class/gpio/export 2>/dev/null  # DC
echo 25 > /sys/class/gpio/export 2>/dev/null  # Reset

echo out > /sys/class/gpio/gpio18/direction 2>/dev/null
echo out > /sys/class/gpio/gpio24/direction 2>/dev/null  
echo out > /sys/class/gpio/gpio25/direction 2>/dev/null

echo "Testing backlight..."
echo "Backlight OFF"
echo 0 > /sys/class/gpio/gpio18/value
sleep 2
echo "Backlight ON"  
echo 1 > /sys/class/gpio/gpio18/value
sleep 2

echo "Testing reset sequence..."
echo 0 > /sys/class/gpio/gpio25/value  # Reset LOW
sleep 0.1
echo 1 > /sys/class/gpio/gpio25/value  # Reset HIGH
sleep 0.1

echo ""
echo "Hardware test complete."
echo "Did you see the backlight turn on/off?"
echo "If no backlight activity, check:"
echo "- GPIO 18 connection to BL pin"
echo "- 3.3V power to VCC"
echo "- Ground connections"