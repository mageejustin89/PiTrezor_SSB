#!/bin/sh
#
# PiTrezor Display Mirror Service
# Created: November 12, 2025  
# Purpose: Start display driver after PiTrezor application
#

echo "Starting PiTrezor Display Mirror Service"

# Read variables from config file
cd /boot
dos2unix -n pitrezor.config /var/volatile/pitrezor.config.fbcp 2>/dev/null || true
source /var/volatile/pitrezor.config.fbcp 2>/dev/null || source /var/volatile/pitrezor.config 2>/dev/null || true

# Sleep to give PiTrezor time to start and go fullscreen
echo "Waiting for PiTrezor to initialize..."
sleep 3

# Check whether to use the fbcp-ili9341 based display mirror
if [ "$ENABLE_FBCPILI9341_DISPLAY" = "1" ]; then
    echo "Starting fbcp-ili9341 display driver"
    
    # Check if advanced driver exists and is executable
    if [ -f "/usr/bin/fbcp-ili9341" ] && [ -x "/usr/bin/fbcp-ili9341" ]; then
        echo "Using optimized fbcp-ili9341 driver"
        /usr/bin/fbcp-ili9341
    elif [ -f "/usr/bin/fbcp" ] && [ -x "/usr/bin/fbcp" ]; then
        echo "Using basic fbcp driver"
        /usr/bin/fbcp
    else
        echo "Error: No display driver found!"
        echo "Expected: /usr/bin/fbcp-ili9341 or /usr/bin/fbcp"
        exit 1
    fi
else
    echo "fbcp-ili9341 display disabled in configuration"
    echo "To enable, set ENABLE_FBCPILI9341_DISPLAY=1 in pitrezor.config"
fi