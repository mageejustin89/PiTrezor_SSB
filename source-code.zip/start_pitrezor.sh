#!/bin/sh
#
# PiTrezor Startup Script (Reverse Transplant Version)
# Created: November 12, 2025
# Purpose: Start PiTrezor with modern universal firmware
#

echo "========================================"
echo " PiTrezor Starting Up"
echo " Firmware: Universal (Modern)"
echo "========================================"

# Change to boot directory and load configuration
cd /boot
dos2unix -n pitrezor.config /var/volatile/pitrezor.config 2>/dev/null || true
source /var/volatile/pitrezor.config 2>/dev/null || true

# Display configuration info
echo "Configuration loaded:"
echo "  TREZOR_OLED_TYPE: ${TREZOR_OLED_TYPE:-not set}"
echo "  ENABLE_FBCPILI9341_DISPLAY: ${ENABLE_FBCPILI9341_DISPLAY:-not set}"
echo "  BITCOIN_ONLY: ${BITCOIN_ONLY:-not set}"

# Determine firmware mode
if [ "$BITCOIN_ONLY" = "1" ]; then
    echo "Note: BITCOIN_ONLY=1 set, but using universal firmware"
    echo "Universal firmware supports all cryptocurrencies including Bitcoin"
fi

echo "Starting PiTrezor-Universal (New Firmware)"

# Start PiTrezor with fullscreen OLED mode
TREZOR_OLED_FULLSCREEN=1 /usr/bin/pitrezor