# PiTrezor Display Integration - Source Files Package

This package contains configuration files and installation instructions for manual setup of PiTrezor with ILI9341 display support.

## 📁 Contents

- **`pitrezor.config`** - Main configuration file with display settings
- **`inittab-additions.txt`** - Service entries to add to `/etc/inittab`  
- **`config-txt-additions.txt`** - Boot configuration for SPI enable
- **`README.md`** - This file

## 🚀 Quick Installation

### 1. Enable SPI Interface
Add to `/boot/config.txt`:
```
dtparam=spi=on
```

### 2. Install Configuration  
Copy `pitrezor.config` to:
- `/boot/pitrezor.config` (primary location)
- `/usr/share/pitrezor/pitrezor.config` (backup location)

### 3. Add Services
Add these lines to `/etc/inittab`:
```
tz:5:respawn:/usr/bin/start_pitrezor
sm:5:respawn:/usr/bin/start_mirrorhdmi
```

### 4. Install Scripts
You'll need the scripts from the source-code package:
- `/usr/bin/start_pitrezor`
- `/usr/bin/start_mirrorhdmi`  
- `/usr/bin/build-fbcp-ili9341` (for auto-build)

## 🔧 Configuration Options

### Display Type
```bash
export FBCP_DISPLAY_TYPE=ILI9341  # ILI9341, ILI9486, ADAFRUIT_PITFT, WAVESHARE35B
```

### GPIO Pins
```bash
export FBCP_GPIO_DC=24          # Data/Control pin
export FBCP_GPIO_RESET=25       # Reset pin  
export FBCP_GPIO_BACKLIGHT=18   # Backlight control pin
```

### Button Mapping
```bash
export TREZOR_GPIO_YES=20       # YES/OK button
export TREZOR_GPIO_NO=13        # NO/Cancel button
```

### Performance
```bash
export FBCP_SPI_SPEED_DIVISOR=40  # 20-60 range, higher = more stable
export TREZOR_OLED_SCALE=5        # 1-16, display zoom level
```

### Firmware Mode
```bash
export BITCOIN_ONLY=0  # 0=Universal, 1=Bitcoin-only
```

## 🔌 Hardware Connections

### Standard ILI9341 Wiring
```
Display Pin  →  Pi Zero GPIO  →  Pi Pin#
VCC          →  3.3V          →  Pin 1
GND          →  Ground        →  Pin 6
CS           →  CE0 (GPIO 8)  →  Pin 24
RESET        →  GPIO 25       →  Pin 22
DC           →  GPIO 24       →  Pin 18
SDI/MOSI     →  GPIO 10       →  Pin 19
SCK          →  GPIO 11       →  Pin 23
LED          →  GPIO 18       →  Pin 12
```

### Button Connections
```
YES Button   →  GPIO 20       →  Pin 38
NO Button    →  GPIO 13       →  Pin 33
```

## 📋 Installation Steps

### Method 1: Manual Configuration
1. Flash PiTrezor image to SD card
2. Mount SD card on computer
3. Edit `/boot/config.txt` - add `dtparam=spi=on`
4. Copy `pitrezor.config` to `/boot/`
5. Boot Pi and SSH in
6. Add inittab entries
7. Install startup scripts
8. Reboot

### Method 2: Image Modification
1. Mount PiTrezor image with loop device
2. Modify configurations in mounted filesystem  
3. Copy scripts to mounted `/usr/bin/`
4. Unmount and flash modified image

## 🐛 Troubleshooting

### Black Screen Issues
1. **Check SPI enabled**: `ls /dev/spi*` should show devices
2. **Verify wiring**: Especially power (3.3V) and ground connections  
3. **Test backlight**: GPIO 18 should control display backlight
4. **Check config**: `TREZOR_OLED_TYPE=0` and `ENABLE_FBCPILI9341_DISPLAY=1`

### Service Issues  
1. **Check inittab**: Services should start automatically on boot
2. **Verify scripts**: Must be executable (`chmod +x`)
3. **Log output**: Check console during boot for error messages
4. **Process check**: `ps aux | grep fbcp` should show running driver

### Build Issues
1. **Internet required**: Auto-build needs to download source code
2. **Dependencies**: git, cmake, build-essential must be installed
3. **Disk space**: Ensure sufficient space for compilation
4. **Fallback**: System will use basic fbcp if advanced build fails

## 📝 Configuration Details

### OLED Type Settings
```bash
export TREZOR_OLED_TYPE=0  # REQUIRED: Disables native OLED to prevent conflicts
```

### Display Enable
```bash  
export ENABLE_FBCPILI9341_DISPLAY=1  # REQUIRED: Enables fbcp-ili9341 driver
```

### Scale Factor
```bash
export TREZOR_OLED_SCALE=5  # 1-16: How much to zoom the display content
```

### Advanced Options
```bash
export FBCP_ENABLE_STATS=1  # Show performance statistics on display
export FBCP_EXTRA_CMAKE_ARGS="-DBACKLIGHT_CONTROL=ON"  # Advanced build options
```

## 🔍 Verification

After installation, verify:
1. **SPI devices exist**: `ls /dev/spi*`
2. **Services running**: `ps aux | grep -E "(pitrezor|fbcp)"`
3. **GPIO exported**: `ls /sys/class/gpio/gpio{18,24,25}`
4. **Framebuffer active**: `ls /dev/fb*`
5. **Configuration loaded**: Check startup messages

## 📚 References

- [PiTrezor Project](https://github.com/satoshilabs/pitrezor)
- [fbcp-ili9341 Driver](https://github.com/juj/fbcp-ili9341)  
- [Raspberry Pi GPIO](https://pinout.xyz/)
- [SPI Configuration](https://www.raspberrypi.org/documentation/hardware/raspberrypi/spi/)

---

**Created: November 12, 2025**  
**Version: Reverse Transplant Method**